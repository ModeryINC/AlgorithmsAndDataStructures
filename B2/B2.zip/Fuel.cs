using System;
using System.Collections.Generic;
using System.Text;

namespace B2 {
    enum Fuel {
        Diesel = 100,
        Nuclear = 15,
        Hydrogen = 30
    }
}
