using System;

namespace AlgorithmsAndDataStructures {
    public class Variables {
        private float a = 6;
        private float b = 3;

        public float A {get {return a; } set {a = value; } }
        public float B {get {return b; } set {b = value; } }
    }
}